from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, CallbackQueryHandler
from ..keyboards import financial_basics_keyboard, back_button_keyboard

def register_financial_basics_handlers(app):
    app.add_handler(CallbackQueryHandler(show_budget_basics, pattern="^basics_budget$"))
    app.add_handler(CallbackQueryHandler(show_passive_income_basics, pattern="^basics_passive_income$"))
    app.add_handler(CallbackQueryHandler(show_credit_basics, pattern="^basics_credit$"))

async def show_budget_basics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text="""💰 *Формирование бюджета*

Бюджетирование — это первый шаг к финансовой стабильности.
Один из самых популярных методов — правило *50/30/20*:

• 50% — на обязательные расходы (жильё, еда, транспорт)
• 30% — на желания (развлечения, путешествия)
• 20% — сбережения и инвестиции

*Полезные привычки:*
• Ведите учёт доходов и расходов
• Планируйте покупки заранее
• Откладывайте с каждого дохода

📚 *Полезные материалы:*
<a href="https://fincult.info/article/finansovyy-plan-semi/">Финансовый план семьи</a>
<a href="https://fincult.info/article/razumnoe-potreblenie-tratim-s-umom/">Разумное потребление</a>
<a href="https://fincult.info/article/kak-vesti-sovmestnyy-byudzhet/">Как вести совместный бюджет</a>
""",
        parse_mode="HTML", disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ Назад", callback_data="back_to_main")]
        ])
    )

async def show_passive_income_basics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text="""📈 *Пассивный доход*

Пассивный доход — это деньги, которые вы получаете без постоянной работы.

💼 *Источники пассивного дохода:*
• Дивиденды от акций
• Доход от аренды недвижимости
• Облигации и купоны
• Роялти от книг, музыки, патентов

⚠️ *Важно:* инвестируйте только свободные средства и диверсифицируйте риски.

📚 
<a href="https://fincult.info/article/kak-otkryt-vklad-v-banke/">Как выбрать вклад</a>
<a href="https://fincult.info/article/kak-platit-nalog-na-dokhod-po-vkladam-/">Как платить нагол на доход по вкладам</a>
<a href="https://fincult.info/article/passivnyy-dokhod-chto-eto-i-kak-ego-poluchat/">Пассивный доход:и как его получать</a>
""",
        parse_mode="HTML", disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ Назад", callback_data="back_to_main")]
        ])
    )

async def show_credit_basics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text="""⚠️ *Кредиты: как не ошибиться*

Кредит — это финансовый инструмент, требующий осознанного подхода.

🔍 *На что обращать внимание:*
• Процентная ставка и ПСК (полная стоимость кредита)
• Общая сумма переплаты
• Условия досрочного погашения
• Не берите кредит, если ежемесячный платёж > 30% дохода

📚 *Полезно почитать:*
<a href="https://fincult.info/article/v-kakikh-sluchayakh-mozhno-poluchit-lgotnuyu-ipoteku/">Как получить льготную ипотеку</a>
<a href="https://fincult.info/article/kak-oformit-samozapret-na-vydachu-kreditov/">Как оформить самозапрет на выдачу кредитов</a>
<a href="https://fincult.info/article/kak-poluchit-obrazovatelnyy-kredit/">Как получить образовательный кредит</a>
""",
        parse_mode="HTML", disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("◀️ Назад", callback_data="back_to_main")]
        ])
    )
