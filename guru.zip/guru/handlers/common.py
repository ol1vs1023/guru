from telegram import Update
from telegram.ext import ContextTypes, CallbackQueryHandler, CommandHandler
from ..handlers.subscriptions import show_subscriptions_menu
from ..handlers.subscriptions import show_upcoming_payments
from ..keyboards import (
    main_menu_keyboard,
    financial_basics_keyboard,
    calculators_menu_keyboard
)
from ..database import save_user
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    save_user(user)
    if update.message:
        await update.message.reply_text(
            "Привет, я ФинГуру! Выбери раздел:",
            reply_markup=main_menu_keyboard()
        )
    elif update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "Привет, я ФинГуру! Выбери раздел:",
            reply_markup=main_menu_keyboard()
        )

async def restart_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    context.user_data.clear()
    await update.callback_query.edit_message_text(
        "🔄 Бот перезапущен. Выбери раздел:",
        reply_markup=main_menu_keyboard()
    )

async def show_financial_basics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "📚 Основы финансов — выбери тему:",
        reply_markup=financial_basics_keyboard()
    )

async def show_calculators_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "🧮 Выбери калькулятор:",
        reply_markup=calculators_menu_keyboard()
    )
async def back_to_calculators(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "🧮 Выбери калькулятор:",
        reply_markup=calculators_menu_keyboard()
    )    

def register_common_handlers(app):
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(start, pattern="^back_to_main$"))
    app.add_handler(CallbackQueryHandler(restart_bot, pattern="^restart_bot$"))
    app.add_handler(CallbackQueryHandler(show_financial_basics, pattern="^financial_basics$"))
    app.add_handler(CallbackQueryHandler(show_calculators_menu, pattern="^calculators$"))
    app.add_handler(CallbackQueryHandler(back_to_calculators, pattern="^back_to_calculators$"))
    app.add_handler(CallbackQueryHandler(show_subscriptions_menu, pattern="^subscriptions_menu$"))
    app.add_handler(CallbackQueryHandler(show_upcoming_payments, pattern="^upcoming_payments$"))