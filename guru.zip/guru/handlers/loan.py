from decimal import Decimal
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CallbackQueryHandler, ConversationHandler, MessageHandler, filters
from ..keyboards import calculators_menu_keyboard

LOAN_AMOUNT, BANK_SELECTION, CUSTOM_RATE, CUSTOM_TERM, LOAN_TERM = range(5)

BANK_CONDITIONS = {
    "Сбербанк🟢": {"rate": 15.5, "max_term": 30},
    "ВТБ🔵": {"rate": 14.9, "max_term": 25},
    "Т-Банк🟡": {"rate": 16.2, "max_term": 15},
    "Газпромбанк🔵": {"rate": 14.5, "max_term": 30},
    "Условия вручную": {"custom": True}
}

async def loan_calculator_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        "🏦 Кредитный калькулятор\n\nВведите сумму кредита (в рублях):",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_loan")]])
    )
    return LOAN_AMOUNT

async def process_loan_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = float(update.message.text)
        if amount <= 0:
            raise ValueError
        context.user_data['loan_amount'] = amount
        buttons = [[InlineKeyboardButton(bank, callback_data=f"bank_{bank}")] for bank in BANK_CONDITIONS.keys()]
        buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="cancel_loan")])
        await update.message.reply_text("Выберите банк или укажите свои условия:", reply_markup=InlineKeyboardMarkup(buttons))
        return BANK_SELECTION
    except ValueError:
        await update.message.reply_text("Пожалуйста, введите положительное число:")
        return LOAN_AMOUNT

async def process_bank_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    bank = query.data.split('_', 1)[1]
    context.user_data['selected_bank'] = bank
    if bank == "Условия вручную":
        await query.edit_message_text("Введите годовую процентную ставку (%):", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_loan")]]))
        return CUSTOM_RATE
    else:
        bank_data = BANK_CONDITIONS[bank]
        context.user_data['loan_rate'] = bank_data['rate']
        context.user_data['max_term'] = bank_data['max_term']
        await query.edit_message_text(
            f"Банк: {bank}\nСтавка: {bank_data['rate']}%\nМакс. срок: {bank_data['max_term']} лет\n\nВведите срок кредита (в годах):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_loan")]])
        )
        return LOAN_TERM

async def process_custom_rate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        rate = float(update.message.text)
        if rate <= 0:
            raise ValueError
        context.user_data['loan_rate'] = rate
        await update.message.reply_text("Введите максимальный срок кредита (в годах):", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_loan")]]))
        return CUSTOM_TERM
    except ValueError:
        await update.message.reply_text("Пожалуйста, введите положительное число:")
        return CUSTOM_RATE

async def process_loan_term(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        term_years = int(update.message.text)
        amount = context.user_data['loan_amount']
        rate = context.user_data['loan_rate']
        max_term = context.user_data.get('max_term', 30)
        if term_years <= 0 or term_years > max_term:
            await update.message.reply_text(f"Пожалуйста, введите срок от 1 до {max_term} лет:")
            return LOAN_TERM
        term_months = term_years * 12
        monthly_rate = rate / 12 / 100
        coefficient = (monthly_rate * (1 + monthly_rate)**term_months) / ((1 + monthly_rate)**term_months - 1)
        monthly_payment = amount * coefficient
        total_payment = monthly_payment * term_months
        overpayment = total_payment - amount
        bank_name = context.user_data.get('selected_bank', 'вашим условиям')
        result_text = (
            f"📊 Результаты расчета по {bank_name}:\n\n"
            f"• Сумма кредита: {amount:,.2f} ₽\n"
            f"• Ставка: {rate:.2f}%\n"
            f"• Срок: {term_years} лет ({term_months} мес.)\n\n"
            f"💳 Ежемесячный платеж: {monthly_payment:,.2f} ₽\n"
            f"💰 Общая выплата: {total_payment:,.2f} ₽\n"
            f"💸 Переплата: {overpayment:,.2f} ₽\n\n"
            "*Расчет по формуле аннуитетных платежей"
        )
        await update.message.reply_text(result_text, reply_markup=calculators_menu_keyboard())
        return ConversationHandler.END
    except ValueError:
        await update.message.reply_text("Пожалуйста, введите целое число:")
        return LOAN_TERM

async def cancel_loan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.edit_message_text("❌ Расчет отменен", reply_markup=calculators_menu_keyboard())
    return ConversationHandler.END

def register_loan_handlers(app):
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(loan_calculator_start, pattern='^loan_calculator$')],
        states={
            LOAN_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_loan_amount)],
            BANK_SELECTION: [CallbackQueryHandler(process_bank_selection, pattern='^bank_')],
            CUSTOM_RATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_custom_rate)],
            CUSTOM_TERM: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_loan_term)],
            LOAN_TERM: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_loan_term)]
        },
        fallbacks=[CallbackQueryHandler(cancel_loan, pattern='^cancel_loan$')]
    )
    app.add_handler(conv_handler)
