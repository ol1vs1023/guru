
from decimal import Decimal, getcontext
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, CallbackQueryHandler, MessageHandler, filters
from ..keyboards import calculators_menu_keyboard

COMPOUND_INITIAL, COMPOUND_RATE, COMPOUND_YEARS, COMPOUND_FREQ = range(4)

def calculate_compound_interest(principal, annual_rate, years, compounding_freq):
    getcontext().prec = 10
    rate = Decimal(annual_rate) / Decimal(100)
    freq_map = {'yearly': 1, 'quarterly': 4, 'monthly': 12, 'daily': 365}
    n = freq_map.get(compounding_freq.lower(), 1)
    amount = principal * (1 + rate/n) ** (n * years)
    interest = amount - principal
    return {'initial_amount': principal, 'final_amount': amount, 'interest_earned': interest, 'rate': annual_rate, 'years': years, 'compounding': compounding_freq}

async def compound_interest_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data['compound'] = {}
    await query.edit_message_text(
        "📈 Калькулятор сложных процентов\n\nВведите начальную сумму инвестиций:",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_compound")]])
    )
    return COMPOUND_INITIAL

async def process_compound_initial(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = Decimal(update.message.text.replace(',', '.'))
        if amount <= 0:
            raise ValueError
        context.user_data['compound']['principal'] = amount
        await update.message.reply_text("Введите годовую процентную ставку:", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_compound")]]))
        return COMPOUND_RATE
    except:
        await update.message.reply_text("❌ Пожалуйста, введите положительное число:")
        return COMPOUND_INITIAL

async def process_compound_rate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        rate = Decimal(update.message.text.replace(',', '.'))
        if rate <= 0:
            raise ValueError
        context.user_data['compound']['rate'] = rate
        await update.message.reply_text("Введите срок инвестирования (в годах):", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_compound")]]))
        return COMPOUND_YEARS
    except:
        await update.message.reply_text("❌ Пожалуйста, введите положительное число:")
        return COMPOUND_RATE

async def process_compound_years(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        years = int(update.message.text)
        if years <= 0:
            raise ValueError
        context.user_data['compound']['years'] = years
        keyboard = [
            [InlineKeyboardButton("Ежегодно", callback_data="yearly")],
            [InlineKeyboardButton("Ежеквартально", callback_data="quarterly")],
            [InlineKeyboardButton("Ежемесячно", callback_data="monthly")],
            [InlineKeyboardButton("Ежедневно", callback_data="daily")],
            [InlineKeyboardButton("❌ Отмена", callback_data="cancel_compound")]
        ]
        await update.message.reply_text("Выберите частоту начисления процентов:", reply_markup=InlineKeyboardMarkup(keyboard))
        return COMPOUND_FREQ
    except:
        await update.message.reply_text("❌ Пожалуйста, введите целое число лет:")
        return COMPOUND_YEARS

async def show_compound_result(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = context.user_data['compound']
    freq = query.data
    result = calculate_compound_interest(data['principal'], data['rate'], data['years'], freq)
    def format_num(n): return f"{float(n):,.2f}".replace(',', ' ')
    text = (
        f"📊 Результаты расчета:\n\n"
        f"• Начальная сумма: {format_num(result['initial_amount'])} ₽\n"
        f"• Ставка: {result['rate']}% годовых\n"
        f"• Срок: {result['years']} лет\n"
        f"• Начисление: {freq}\n\n"
        f"💵 Итоговая сумма: {format_num(result['final_amount'])} ₽\n"
        f"💰 Заработано процентов: {format_num(result['interest_earned'])} ₽\n\n"
        "*Расчеты приблизительные. Учитывайте налоги и инфляцию."
    )
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Новый расчет", callback_data="compound_interest")],
        [InlineKeyboardButton("◀️ В меню", callback_data="back_to_calculators")]
    ]))
    return ConversationHandler.END

async def cancel_compound(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.edit_message_text("❌ Расчет отменен", reply_markup=calculators_menu_keyboard())
    return ConversationHandler.END

def register_compound_handlers(app):
    compound_conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(compound_interest_start, pattern='^compound_interest$')],
        states={
            COMPOUND_INITIAL: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_compound_initial)],
            COMPOUND_RATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_compound_rate)],
            COMPOUND_YEARS: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_compound_years)],
            COMPOUND_FREQ: [CallbackQueryHandler(show_compound_result, pattern='^(yearly|quarterly|monthly|daily)$')]
        },
        fallbacks=[CallbackQueryHandler(cancel_compound, pattern='^cancel_compound$')]
    )
    app.add_handler(compound_conv_handler)
