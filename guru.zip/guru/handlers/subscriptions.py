
import sqlite3
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, CallbackQueryHandler, MessageHandler, filters, ConversationHandler
)
from ..keyboards import subscriptions_menu_keyboard, finance_menu_keyboard
from ..utils.helpers import calculate_next_payment
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "finance_bot.db"
conn = sqlite3.connect(DB_PATH)
DB_NAME = "finance_bot.db"

SUBS_NAME, SUBS_AMOUNT, SUBS_DAY = range(3)

async def show_subscriptions_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "💸 Управление подписками:",
        reply_markup=subscriptions_menu_keyboard()
    )
async def add_subscription_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("Введите название подписки:")
    return SUBS_NAME

async def process_subscription_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["subscription_name"] = update.message.text
    await update.message.reply_text("Введите сумму подписки:")
    return SUBS_AMOUNT

async def process_subscription_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = float(update.message.text.replace(",", "."))
        if amount <= 0:
            raise ValueError
        context.user_data["subscription_amount"] = amount
        await update.message.reply_text("В какой день месяца происходит списание? (1-31):")
        return SUBS_DAY
    except ValueError:
        await update.message.reply_text("Пожалуйста, введите положительное число:")
        return SUBS_AMOUNT

async def process_subscription_payment_day(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        day = int(update.message.text)
        if not 1 <= day <= 31:
            raise ValueError
        next_payment = calculate_next_payment(day)
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO subscriptions (user_id, name, amount, payment_day, next_payment) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                update.effective_user.id,
                context.user_data["subscription_name"],
                context.user_data["subscription_amount"],
                day,
                next_payment
            )
        )
        conn.commit()
        conn.close()
        await update.message.reply_text(
            f"✅ Подписка {context.user_data['subscription_name']} добавлена!\n"
            f"Следующий платеж: {next_payment}",
            reply_markup=subscriptions_menu_keyboard()
        )
        return ConversationHandler.END
    except ValueError:
        await update.message.reply_text("Введите число от 1 до 31:")
        return SUBS_DAY

async def list_subscriptions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, name, amount, payment_day, next_payment "
        "FROM subscriptions WHERE user_id = ? AND is_active = 1 ORDER BY next_payment",
        (query.from_user.id,)
    )
    subs = cursor.fetchall()
    conn.close()

    if not subs:
        await query.edit_message_text("У вас нет активных подписок", reply_markup=subscriptions_menu_keyboard())
        return

    text = "📋 Ваши подписки:\n\n" 
    buttons = []
    for sub in subs:
        sub_id, name, amount, day, next_pay = sub
        text += f"{name}: {amount} ₽ (платеж {day} числа)\nСледующий: {next_pay}\n\n"
        buttons.append([InlineKeyboardButton(f"❌ Отключить {name}", callback_data=f"disable_sub_{sub_id}")])

    buttons.append([InlineKeyboardButton("◀️ Назад", callback_data="back_to_finance_menu")])
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons))

async def disable_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    data = update.callback_query.data
    try:
        sub_id = int(data.replace("disable_sub_", ""))
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE subscriptions SET is_active = 0 WHERE id = ?", (sub_id,))
        conn.commit()
        conn.close()
        await update.callback_query.edit_message_text(
            "❌ Подписка отключена.",
            reply_markup=subscriptions_menu_keyboard()
        )
    except Exception as e:
        await update.callback_query.edit_message_text(
            f"⚠️ Ошибка при отключении подписки: {e}",
            reply_markup=subscriptions_menu_keyboard()
        )

async def show_upcoming_payments(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    user_id = update.callback_query.from_user.id

    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT name, amount, next_payment FROM subscriptions "
        "WHERE user_id = ? AND is_active = 1 ORDER BY next_payment ASC",
        (user_id,)
    )
    subscriptions = cursor.fetchall()
    conn.close()

    if not subscriptions:
        await update.callback_query.edit_message_text(
            "🔕 Нет активных подписок.",
            reply_markup=subscriptions_menu_keyboard()
        )
        return

    text = "📅 *Ближайшие платежи:*\n\n" "🔔Я напомню о списании за день\n\n"
            
    for name, amount, next_date in subscriptions:
        text += f"• {name} — {amount:.2f} ₽  ({next_date})\n"

    await update.callback_query.edit_message_text(
        text,
        reply_markup=subscriptions_menu_keyboard(),
        parse_mode="Markdown"
    )
    
async def show_finance_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "💰 Учёт финансов — выбери действие:",
        reply_markup=finance_menu_keyboard()
    )

def register_subscription_handlers(app):
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_subscription_start, pattern="^add_subscription$")],
        states={
            SUBS_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_subscription_name)],
            SUBS_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_subscription_amount)],
            SUBS_DAY: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_subscription_payment_day)],
        },
        fallbacks=[]
    )

    app.add_handler(conv_handler)
    app.add_handler(CallbackQueryHandler(list_subscriptions, pattern="^list_subscriptions$"))
    app.add_handler(CallbackQueryHandler(disable_subscription, pattern="^disable_sub_"))
    app.add_handler(CallbackQueryHandler(show_finance_menu, pattern="^back_to_finance_menu$"))
    app.add_handler(CallbackQueryHandler(show_subscriptions_menu, pattern='^subscriptions_menu$'))