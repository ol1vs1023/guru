
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, ConversationHandler, CallbackQueryHandler,
    MessageHandler, CommandHandler, filters
)
from ..database import add_debt, get_user_debts, delete_debt

AMOUNT, NAME, DESCRIPTION = range(3)

# Главное меню долгов
async def show_debts_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📥 Свой долг", callback_data="own_debt")],
        [InlineKeyboardButton("📤 Мне должны", callback_data="owed_to_me")],
        [InlineKeyboardButton("📋 Показать мои долги", callback_data="show_my_debts")],
        [InlineKeyboardButton("◀️ Назад", callback_data="finance_menu")]
    ])
    await update.callback_query.edit_message_text("💸 Выберите тип долга:", reply_markup=keyboard)

# Начало записи долга
async def start_own_debt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['is_owed_to_me'] = 0
    await update.callback_query.answer()
    await update.callback_query.message.reply_text("Сколько вы должны?")
    return AMOUNT

async def start_owed_to_me(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['is_owed_to_me'] = 1
    await update.callback_query.answer()
    await update.callback_query.message.reply_text("Сколько вам должны?")
    return AMOUNT

async def input_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        context.user_data['amount'] = float(update.message.text)
    except ValueError:
        await update.message.reply_text("Введите сумму числом:")
        return AMOUNT
    await update.message.reply_text("Кому вы должны? / Кто вам должен?")
    return NAME

async def input_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['debtor_name'] = update.message.text
    await update.message.reply_text("Введите описание долга (или '-' если без описания):")
    return DESCRIPTION

async def input_description(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    description = update.message.text if update.message.text != "-" else ""
    amount = context.user_data['amount']
    debtor_name = context.user_data['debtor_name']
    is_owed_to_me = context.user_data.get('is_owed_to_me', 0)
    add_debt(user_id, amount, description, debtor_name, is_owed_to_me)

    reply_markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("◀️ Назад в меню долгов", callback_data="debts_menu")]
    ])
    await update.message.reply_text("✅ Долг успешно сохранён.", reply_markup=reply_markup)
    return ConversationHandler.END

# Меню "Показать мои долги"
async def show_user_debts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📃 Посмотреть все долги", callback_data="view_all_debts")],
        [InlineKeyboardButton("❌ Удалить долги", callback_data="delete_menu")],
        [InlineKeyboardButton("◀️ Назад", callback_data="debts_menu")]
    ])
    await update.callback_query.message.edit_text("📋 Меню просмотра долгов:", reply_markup=keyboard)

# Просмотр всех долгов
async def view_all_debts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    user_id = update.callback_query.from_user.id
    debts = get_user_debts(user_id)

    if not debts:
        await update.callback_query.message.reply_text("У вас пока нет долгов.")
        return

    text = "📋 Ваши долги:"

    for debt in debts:
        amount = debt[2]
        desc = debt[3] or "—"
        name = debt[4] or "Не указано"
        direction = "📤 Вам должны" if debt[5] else "📥 Вы должны"
        text += f"{direction}: {amount} ₽\nКому/от кого: {name}\nОписание: {desc}\n\n"

        await update.callback_query.message.reply_text(text)

# Меню удаления
async def delete_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    user_id = update.callback_query.from_user.id
    debts = get_user_debts(user_id)

    if not debts:
        await update.callback_query.message.reply_text("Удалять нечего — у вас нет долгов.")
        return

    for debt in debts:
        debt_id = debt[0]
        amount = debt[2]
        desc = debt[3] or "—"
        name = debt[4] or "Не указано"
        direction = "📤 Вам должны" if debt[5] else "📥 Вы должны"

        text = f"{direction}: {amount} ₽\nКому/от кого: {name}\nОписание: {desc}"
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Удалить", callback_data=f"delete_debt_{debt_id}")]
        ])
        await update.callback_query.message.reply_text(text, reply_markup=keyboard)

# Обработка удаления
async def handle_delete_debt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    try:
        debt_id = int(update.callback_query.data.split("_")[-1])
        delete_debt(debt_id)
        await update.callback_query.message.edit_text("✅ Долг удалён.")
    except:
        await update.callback_query.message.edit_text("❌ Не удалось удалить долг.")

# Отмена
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Операция отменена.")
    return ConversationHandler.END

# Регистрация хендлеров
def register_debts_handler(app):
    app.add_handler(CallbackQueryHandler(show_debts_menu, pattern="^debts_menu$"))
    app.add_handler(CallbackQueryHandler(show_user_debts, pattern="^show_my_debts$"))
    app.add_handler(CallbackQueryHandler(view_all_debts, pattern="^view_all_debts$"))
    app.add_handler(CallbackQueryHandler(delete_menu, pattern="^delete_menu$"))
    app.add_handler(CallbackQueryHandler(handle_delete_debt, pattern="^delete_debt_\\d+$"))

    debt_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_own_debt, pattern="^own_debt$"),
            CallbackQueryHandler(start_owed_to_me, pattern="^owed_to_me$")
        ],
        states={
            AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_amount)],
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_name)],
            DESCRIPTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_description)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_message=False
    )
    app.add_handler(debt_conv)
