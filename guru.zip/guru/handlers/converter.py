
import aiohttp
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, CallbackQueryHandler, ConversationHandler,
    MessageHandler, filters
)

CHOOSE_FROM, CHOOSE_TO, ENTER_AMOUNT = range(3)

def register_converter_handlers(app):
    app.add_handler(CallbackQueryHandler(show_exchange_rates, pattern='^exchange_rates$'))

    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_conversion_flow, pattern='^start_conversion$')],
        states={
            CHOOSE_FROM: [CallbackQueryHandler(choose_from_currency, pattern='^from_')],
            CHOOSE_TO: [CallbackQueryHandler(choose_to_currency, pattern='^to_')],
            ENTER_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, convert_currency)],
        },
        fallbacks=[CallbackQueryHandler(cancel_conversion, pattern='^cancel_conversion$')],
        per_message=False
    )
    app.add_handler(conv_handler)

async def show_exchange_rates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("https://www.cbr-xml-daily.ru/daily_json.js") as response:
                data = await response.json(content_type=None)
                valute = data["Valute"]
                usd = valute["USD"]["Value"]
                eur = valute["EUR"]["Value"]
                cny = valute["CNY"]["Value"]
                gbp = valute["GBP"]["Value"]
                jpy = valute["JPY"]["Value"]
                byn = valute["BYN"]["Value"]

            btc = eth = None
            async with session.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd") as crypto_resp:
                crypto_data = await crypto_resp.json()
                btc = crypto_data["bitcoin"]["usd"]
                eth = crypto_data["ethereum"]["usd"]

        text = (
            "💱 Актуальные курсы:\n"
            f"• 🇺🇸 USD: {usd:.2f} ₽\n"
            f"• 🇪🇺 EUR: {eur:.2f} ₽\n"
            f"• 🇨🇳 CNY: {cny:.2f} ₽\n\n"
            f"• 🇬🇧 GBP: {gbp:.2f} ₽\n"
            f"• 🇯🇵 JPY: {jpy:.2f} ₽\n"
            f"• 🇧🇾 BYN: {byn:.2f} ₽\n"
            "🪙 Криптовалюты:\n"
            f"• Bitcoin (BTC): ${btc:,.2f}\n"
            f"• Ethereum (ETH): ${eth:,.2f}"
        )
        reply_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Конвертировать", callback_data="start_conversion")],
            [InlineKeyboardButton("◀️ Назад", callback_data="back_to_main")]
        ])

        await update.callback_query.message.edit_text(text, reply_markup=reply_markup)
    except Exception as e:
        print("Ошибка загрузки курсов:", e)
        await update.callback_query.message.edit_text("❌ Не удалось загрузить курсы валют.")

async def start_conversion_flow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    context.user_data.clear()
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("RUB", callback_data="from_RUB"),
         InlineKeyboardButton("USD", callback_data="from_USD"),
         InlineKeyboardButton("EUR", callback_data="from_EUR")],
        [InlineKeyboardButton("CNY", callback_data="from_CNY"),
         InlineKeyboardButton("GBP", callback_data="from_GBP"),
         InlineKeyboardButton("JPY", callback_data="from_JPY")],
        [InlineKeyboardButton("BTC", callback_data="from_BTC"),
         InlineKeyboardButton("ETH", callback_data="from_ETH")],
        [InlineKeyboardButton("❌ Отмена", callback_data="cancel_conversion")]
    ])
    await update.callback_query.message.edit_text("Выберите валюту ИСТОЧНИК:", reply_markup=keyboard)
    return CHOOSE_FROM

async def choose_from_currency(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    context.user_data["from_currency"] = update.callback_query.data.replace("from_", "")
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("RUB", callback_data="to_RUB"),
         InlineKeyboardButton("USD", callback_data="to_USD"),
         InlineKeyboardButton("EUR", callback_data="to_EUR")],
        [InlineKeyboardButton("CNY", callback_data="to_CNY"),
         InlineKeyboardButton("GBP", callback_data="to_GBP"),
         InlineKeyboardButton("JPY", callback_data="to_JPY")],
        [InlineKeyboardButton("BTC", callback_data="to_BTC"),
         InlineKeyboardButton("ETH", callback_data="to_ETH")],
        [InlineKeyboardButton("❌ Отмена", callback_data="cancel_conversion")]
    ])
    await update.callback_query.message.edit_text("Выберите валюту НАЗНАЧЕНИЯ:", reply_markup=keyboard)
    return CHOOSE_TO

async def choose_to_currency(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    context.user_data["to_currency"] = update.callback_query.data.replace("to_", "")
    from_curr = context.user_data['from_currency']
    to_curr = context.user_data['to_currency']
    await update.callback_query.message.edit_text(f"Введите сумму в {from_curr} для конвертации в {to_curr}:")
    return ENTER_AMOUNT

async def convert_currency(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = float(update.message.text.replace(',', '.'))
        if amount <= 0:
            raise ValueError

        from_curr = context.user_data['from_currency']
        to_curr = context.user_data['to_currency']

        async with aiohttp.ClientSession() as session:
            async with session.get("https://www.cbr-xml-daily.ru/daily_json.js") as response:
             data = await response.json(content_type=None)
            rates = data["Valute"]
            rates["RUB"] = {"Value": 1}

            async with session.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=rub") as crypto:
                crypto_data = await crypto.json()
                rates["BTC"] = {"Value": crypto_data["bitcoin"]["rub"]}
                rates["ETH"] = {"Value": crypto_data["ethereum"]["rub"]}

        from_rate = rates[from_curr]["Value"]
        to_rate = rates[to_curr]["Value"]

        result = amount * (from_rate / to_rate)

        await update.message.reply_text(
            f"💱 {amount:.2f} {from_curr} ≈ {result:.6f} {to_curr}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔁 Новая конвертация", callback_data="start_conversion")],
                [InlineKeyboardButton("◀️ Назад", callback_data="exchange_rates")]
            ])
        )
        return ConversationHandler.END
    except Exception:
        await update.message.reply_text("❌ Ошибка. Введите сумму ещё раз:")
        return ENTER_AMOUNT

async def cancel_conversion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.message.edit_text("❌ Конвертация отменена.")
    return ConversationHandler.END
