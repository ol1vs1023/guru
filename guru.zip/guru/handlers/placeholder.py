
from telegram import Update
from telegram.ext import ContextTypes, CallbackQueryHandler

async def show_under_construction(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.message.edit_text("🔧 Этот раздел пока в разработке.")

def register_placeholder_handlers(app):
    app.add_handler(CallbackQueryHandler(show_under_construction, pattern="^expenses_menu$"))
    app.add_handler(CallbackQueryHandler(show_under_construction, pattern="^stats_menu$"))
