
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, CallbackQueryHandler, MessageHandler, filters
from ..keyboards import calculators_menu_keyboard

(
    ENTER_GOAL,
    SELECT_FREQUENCY,
    ENTER_AMOUNT_PER_PERIOD,
    ASK_INTEREST,
    ENTER_INTEREST
) = range(5)

FREQUENCIES = {
    "daily": 365,
    "weekly": 52,
    "monthly": 12
}

async def savings_goal_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "💡 Сколько вы хотите накопить? (₽)",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_savings")]])
        )
    return ENTER_GOAL

async def enter_goal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        goal = float(update.message.text.replace(",", "."))
        if goal <= 0:
            raise ValueError
        context.user_data["goal"] = goal
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📆 Каждый день", callback_data="daily")],
            [InlineKeyboardButton("📅 Каждую неделю", callback_data="weekly")],
            [InlineKeyboardButton("🗓️ Каждый месяц", callback_data="monthly")]
        ])
        await update.message.reply_text("🗓️ Как часто вы планируете откладывать деньги?", reply_markup=keyboard)
        return SELECT_FREQUENCY
    except ValueError:
        await update.message.reply_text("❌ Введите положительное число.")
        return ENTER_GOAL

async def select_frequency(update: Update, context: ContextTypes.DEFAULT_TYPE):
    frequency = update.callback_query.data
    await update.callback_query.answer()
    context.user_data["frequency"] = frequency
    await update.callback_query.edit_message_text(
        f"💸 Сколько вы будете откладывать {frequency}?",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="cancel_savings")]])
    )
    return ENTER_AMOUNT_PER_PERIOD

async def enter_amount_per_period(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        amount = float(update.message.text.replace(",", "."))
        if amount <= 0:
            raise ValueError
        context.user_data["amount_per_period"] = amount
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Да", callback_data="use_interest")],
            [InlineKeyboardButton("❌ Нет", callback_data="no_interest")]
        ])
        await update.message.reply_text(
            "🏦 Вы хотите учитывать процент на сберегательном счёте?",
            reply_markup=keyboard
        )
        return ASK_INTEREST
    except ValueError:
        await update.message.reply_text("❌ Введите положительное число.")
        return ENTER_AMOUNT_PER_PERIOD

async def ask_interest(update: Update, context: ContextTypes.DEFAULT_TYPE):
    answer = update.callback_query.data
    await update.callback_query.answer()
    if answer == "use_interest":
        await update.callback_query.edit_message_text("📈 Введите годовую процентную ставку (%):")
        return ENTER_INTEREST
    else:
        context.user_data["interest"] = 0.0
        return await show_goal_result(update, context)

async def enter_interest(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        rate = float(update.message.text.replace(",", "."))
        if rate < 0:
            raise ValueError
        context.user_data["interest"] = rate
        return await show_goal_result(update, context)
    except ValueError:
        await update.message.reply_text("❌ Введите корректную процентную ставку.")
        return ENTER_INTEREST

async def show_goal_result(update: Update, context: ContextTypes.DEFAULT_TYPE):
    goal = context.user_data["goal"]
    freq = context.user_data["frequency"]
    amount = context.user_data["amount_per_period"]
    rate = context.user_data.get("interest", 0.0)

    periods_per_year = FREQUENCIES[freq]
    r = rate / 100 / periods_per_year if rate > 0 else 0

    total = 0.0
    periods = 0
    while total < goal:
        total += amount
        if r > 0:
            total *= (1 + r)
        periods += 1

    years = periods / periods_per_year

    result = f"""🎯 Цель: {goal:.2f} ₽
📅 Периодичность: {freq}
💸 Взнос: {amount:.2f} ₽
🏦 Процент: {rate:.2f} %
⏳ Нужно периодов: {periods} ({years:.1f} лет)
📈 Вы накопите: {total:.2f} ₽"""

    if update.callback_query:
        await update.callback_query.edit_message_text(
            result,
            reply_markup=calculators_menu_keyboard()
        )
    elif update.message:
        await update.message.reply_text(
            result,
            reply_markup=calculators_menu_keyboard()
        )
    else:
        print("❌ Ошибка: ни callback_query, ни message в update.")

    return ConversationHandler.END

async def cancel_savings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "❌ Расчёт отменён.",
            reply_markup=calculators_menu_keyboard()
        )
    else:
        await update.message.reply_text(
            "❌ Расчёт отменён.",
            reply_markup=calculators_menu_keyboard()
        )
    return ConversationHandler.END

def register_savings_handlers(app):
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(savings_goal_start, pattern="^savings_calculator$")],
        states={
            ENTER_GOAL: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_goal)],
            SELECT_FREQUENCY: [CallbackQueryHandler(select_frequency)],
            ENTER_AMOUNT_PER_PERIOD: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_amount_per_period)],
            ASK_INTEREST: [CallbackQueryHandler(ask_interest)],
            ENTER_INTEREST: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_interest)],
        },
        fallbacks=[CallbackQueryHandler(cancel_savings, pattern="^cancel_savings$")],
        per_message=False
    )
    app.add_handler(conv_handler)
