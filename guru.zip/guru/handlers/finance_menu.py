
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CallbackQueryHandler

async def show_finance_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📑 Подписки", callback_data="subscriptions_menu")],
        [InlineKeyboardButton("💸 Долги", callback_data="debts_menu")],
        [InlineKeyboardButton("◀️ Назад", callback_data="back_to_main")]
    ])
    await update.callback_query.message.edit_text("💼 Учёт финансов:", reply_markup=keyboard)

def register_finance_menu_handler(app):
    app.add_handler(CallbackQueryHandler(show_finance_menu, pattern="^finance_menu$"))
