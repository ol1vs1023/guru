from telegram import InlineKeyboardMarkup, InlineKeyboardButton

def main_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📚 Основы финансов", callback_data='financial_basics')],
        [InlineKeyboardButton("🧮 Калькуляторы", callback_data='calculators')],
        [InlineKeyboardButton("💱 Курсы валют", callback_data='exchange_rates')],
        [InlineKeyboardButton("💼 Учет финансов", callback_data='finance_menu')],
        [InlineKeyboardButton("🔄 Перезапустить бота", callback_data='restart_bot')],
    ])


def financial_basics_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💰 Формирование бюджета", callback_data='basics_budget')],
        [InlineKeyboardButton("📈 Пассивный доход", callback_data='basics_passive_income')],
        [InlineKeyboardButton("⚠️ Кредиты: как не ошибиться", callback_data='basics_credit')],
        [InlineKeyboardButton("◀️ Назад", callback_data='back_to_main')]
    ])

def calculators_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("Сложные проценты💯", callback_data='compound_interest')],
        [InlineKeyboardButton("Кредитный калькулятор💳", callback_data='loan_calculator')],
        [InlineKeyboardButton("Накопительный калькулятор💰", callback_data='savings_calculator')],
        [InlineKeyboardButton("◀️ Назад", callback_data='back_to_main')]
    ])


def finance_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔔 Подписки", callback_data='subscriptions_menu')],
        [InlineKeyboardButton("💸 Долги", callback_data='debts_menu')],
        [InlineKeyboardButton("◀️ Назад", callback_data='back_to_main')]
    ])

def subscriptions_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Добавить подписку", callback_data='add_subscription')],
        [InlineKeyboardButton("📋 Мои подписки", callback_data='list_subscriptions')],
        [InlineKeyboardButton("🔔 Ближайшие платежи", callback_data='upcoming_payments')],
        [InlineKeyboardButton("◀️ Назад", callback_data='finance_menu')]
    ])

def back_button_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("◀️ Назад", callback_data='back_to_main')]
    ])
