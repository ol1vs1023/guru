from pathlib import Path

# Путь к базе данных относительно файла main.py
DB_PATH = Path(__file__).resolve().parent / "finance_bot.db"