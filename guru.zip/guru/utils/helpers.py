from datetime import datetime, timedelta

def calculate_next_payment(day: int) -> str:
    today = datetime.now()
    year, month = today.year, today.month
    if today.day > day:
        month += 1
        if month > 12:
            month = 1
            year += 1
    try:
        next_date = datetime(year, month, day)
    except ValueError:
        # Если указан день, превышающий кол-во дней в месяце
        month += 1
        if month > 12:
            month = 1
            year += 1
        next_date = datetime(year, month, 1) - timedelta(days=1)
    return next_date.strftime("%Y-%m-%d")
