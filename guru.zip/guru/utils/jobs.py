
import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "finance_bot.db"

async def check_upcoming_payments(context):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    today = datetime.now().strftime('%Y-%m-%d')

    cursor.execute("""
        SELECT user_id, name, amount, next_payment FROM subscriptions
        WHERE is_active = 1
    """)

    results = cursor.fetchall()

    for user_id, name, amount, next_payment in results:
        if not next_payment:
            continue
        try:
            payment_date = datetime.strptime(next_payment, '%Y-%m-%d')
            days_left = (payment_date - datetime.now()).days
            if days_left == 1:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=(
                        f"⏰ Напоминание: подписка <b>{name}</b> на сумму <b>{amount:.2f} ₽</b> "
                        f"будет списана <b>{next_payment}</b>."
                    ),
                    parse_mode='HTML'
                )
                print(f"✔ Уведомление отправлено пользователю {user_id} — {name}")
        except Exception as e:
            print(f"❌ Ошибка отправки пользователю {user_id}: {e}")

    conn.close()


def schedule_jobs(app):
    app.job_queue.run_repeating(check_upcoming_payments, interval=86400, first=10)
