import sqlite3

from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "finance_bot.db"
conn = sqlite3.connect(DB_PATH)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Таблица расходов
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        category TEXT NOT NULL,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Таблица подписок
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        amount REAL NOT NULL,
        payment_day INTEGER NOT NULL,
        next_payment TEXT NOT NULL,
        is_active INTEGER DEFAULT 1
    )
    """)
    print("✅ Таблица subscriptions создана.")

    # Таблица уведомлений
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        daily_report INTEGER DEFAULT 0
    )
    """)

   
    conn.commit()
    conn.close()
   # Таблица долгов
def create_debts_table():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS debts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        description TEXT,
        debtor_name TEXT,
        is_owed_to_me INTEGER,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()
    conn.close()

def add_debt(user_id, amount, description, debtor_name, is_owed_to_me):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO debts (user_id, amount, description, debtor_name, is_owed_to_me) VALUES (?, ?, ?, ?, ?)",
        (user_id, amount, description, debtor_name, is_owed_to_me)
    )
    conn.commit()
    conn.close()

def get_user_debts(user_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM debts WHERE user_id = ?", (user_id,))
    results = cursor.fetchall()
    conn.close()
    return results
# Удаление долга
def delete_debt(debt_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM debts WHERE id = ?", (debt_id,))
    conn.commit()
    conn.close()

# === USER TRACKING ===
import os
print("Текущий путь к базе данных:", os.path.abspath("finance_bot.db"))


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# Получаем путь к корню проекта, где main.py
DB_PATH = Path(__file__).resolve().parent.parent / "finance_bot.db"

def init_user_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            full_name TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_user(user):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "INSERT OR IGNORE INTO users (user_id, username, full_name) VALUES (?, ?, ?)",
        (user.id, user.username, user.full_name)
    )
    conn.commit()
    conn.close()