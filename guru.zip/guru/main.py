import os
from dotenv import load_dotenv
from telegram.ext import Application
from .handlers.finance_menu import register_finance_menu_handler
from .handlers.debts import register_debts_handler
from .handlers.common import register_common_handlers
from .handlers.converter import register_converter_handlers
from .handlers.compound import register_compound_handlers
from .handlers.loan import register_loan_handlers
from .handlers.savings_goal_calculator import register_savings_handlers
from .handlers.financial_basics import register_financial_basics_handlers
from .handlers.subscriptions import register_subscription_handlers
from .utils.jobs import schedule_jobs
from .database import init_db, create_debts_table, init_user_db
from .handlers.debts import register_debts_handler
from .handlers.placeholder import register_placeholder_handlers
load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise EnvironmentError("Переменная окружения BOT_TOKEN не установлена")


def main():
    init_db()
    create_debts_table()
    init_user_db()
    import os
    print("Текущий путь к базе данных:", os.path.abspath("finance_bot.db"))
    app = Application.builder().token(TOKEN).build()
    
    register_finance_menu_handler(app)
    register_placeholder_handlers(app)
    register_debts_handler(app)
    register_financial_basics_handlers(app)
    register_common_handlers(app)
    register_converter_handlers(app)
    register_compound_handlers(app)
    register_loan_handlers(app)
    register_savings_handlers(app)  
    register_subscription_handlers(app)
    schedule_jobs(app) 

    print("Бот запущен...")
    app.run_polling()

if __name__ == "__main__":
    main()
