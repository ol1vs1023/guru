
import os
import sqlite3

# Определим абсолютный путь к базе (где бот её создаёт)
db_path = os.path.abspath("finance_bot.db")

if not os.path.exists(db_path):
    print(f"[❌] База данных не найдена: {db_path}")
    exit()

# Подключаемся к базе
conn = sqlite3.connect(db_path)
c = conn.cursor()

try:
    c.execute("SELECT * FROM users")
    rows = c.fetchall()

    if not rows:
        print("[ℹ️] Пользователи не найдены.")
    else:
        print("🧑 Пользователи бота:")
        for row in rows:
            print(f"ID: {row[0]}, Username: @{row[1]}, Имя: {row[2]}")
except sqlite3.OperationalError as e:
    print(f"[❌] Ошибка: {e}")
finally:
    conn.close()
